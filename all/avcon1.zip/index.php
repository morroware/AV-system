<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Audio Source Toggle</title>
    <link rel="stylesheet" href="styles.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <style>
        .toggle-container {
            max-width: 600px;
            margin: 0 auto;
            padding: 3rem;
            text-align: center;
        }

        .toggle-section {
            background: var(--surface-color);
            padding: 3rem;
            border-radius: 12px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
            margin-bottom: 2rem;
        }

        .toggle-title {
            font-size: 2.5em;
            color: var(--primary-color);
            margin-bottom: 1rem;
            font-weight: 600;
        }

        .toggle-subtitle {
            font-size: 1.2em;
            color: var(--text-color);
            margin-bottom: 2.5rem;
            opacity: 0.8;
        }

        .toggle-switch-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 2rem;
            margin: 2rem 0;
        }

        .source-labels {
            display: flex;
            justify-content: space-between;
            width: 100%;
            max-width: 400px;
            margin-bottom: 1rem;
        }

        .source-label {
            font-size: 1.3em;
            font-weight: 600;
            padding: 1rem;
            border-radius: 8px;
            transition: all 0.3s ease;
        }

        .source-label.active {
            background: var(--primary-color);
            color: var(--bg-color);
            transform: scale(1.05);
        }

        .source-label.inactive {
            background: rgba(255, 255, 255, 0.1);
            color: var(--text-color);
            opacity: 0.6;
        }

        /* Custom Toggle Switch */
        .toggle-switch {
            position: relative;
            width: 200px;
            height: 80px;
            background: #333;
            border-radius: 40px;
            cursor: pointer;
            transition: all 0.3s ease;
            border: 3px solid var(--primary-color);
        }

        .toggle-switch.wireless {
            background: var(--secondary-color);
        }

        .toggle-slider {
            position: absolute;
            top: 6px;
            left: 6px;
            width: 65px;
            height: 65px;
            background: white;
            border-radius: 50%;
            transition: all 0.3s ease;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5em;
        }

        .toggle-switch.wireless .toggle-slider {
            transform: translateX(120px);
        }

        .status-display {
            margin: 2rem 0;
            padding: 1.5rem;
            background: rgba(0, 0, 0, 0.2);
            border-radius: 8px;
            border-left: 4px solid var(--secondary-color);
        }

        .current-source {
            font-size: 1.4em;
            font-weight: 600;
            color: var(--secondary-color);
            margin-bottom: 0.5rem;
        }

        .zone-list {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-top: 2rem;
        }

        .zone-item {
            background: rgba(0, 0, 0, 0.2);
            padding: 1rem;
            border-radius: 6px;
            border-left: 3px solid var(--primary-color);
            transition: all 0.3s ease;
        }

        .zone-item.updating {
            border-left-color: var(--warning-color);
            background: rgba(255, 152, 0, 0.1);
        }

        .zone-item.success {
            border-left-color: var(--success-color);
            background: rgba(76, 175, 80, 0.1);
        }

        .zone-item.error {
            border-left-color: var(--error-color);
            background: rgba(207, 102, 121, 0.1);
        }

        .loading-indicator {
            display: none;
            margin: 1rem 0;
        }

        .spinner {
            width: 40px;
            height: 40px;
            border: 4px solid rgba(187, 134, 252, 0.3);
            border-top: 4px solid var(--primary-color);
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin: 0 auto;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        .progress-bar {
            width: 100%;
            height: 6px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 3px;
            overflow: hidden;
            margin: 1rem 0;
        }

        .progress-fill {
            height: 100%;
            background: var(--secondary-color);
            width: 0%;
            transition: width 0.3s ease;
        }

        .back-button {
            margin-top: 2rem;
        }

        @media (max-width: 768px) {
            .toggle-container {
                padding: 1.5rem;
            }
            
            .toggle-section {
                padding: 2rem;
            }
            
            .toggle-title {
                font-size: 2em;
            }
            
            .source-labels {
                flex-direction: column;
                gap: 1rem;
            }
            
            .toggle-switch {
                width: 160px;
                height: 60px;
            }
            
            .toggle-slider {
                width: 50px;
                height: 50px;
                top: 2px;
                left: 2px;
            }
            
            .toggle-switch.wireless .toggle-slider {
                transform: translateX(100px);
            }
        }
    </style>
</head>
<body>
    <div class="content-wrapper">
        <header>
            <div class="logo-title-group">
                <h1>Audio Source Control</h1>
            </div>
            <div class="header-buttons">
                <a href="http://192.168.8.127" class="button home-button">
                    Back to Main Control
                </a>
            </div>
        </header>

        <div class="toggle-container">
            <div class="toggle-section">
                <h2 class="toggle-title">Audio Source Toggle</h2>
                <p class="toggle-subtitle">Switch all audio zones between RockBot and Wireless Mic</p>

                <div class="source-labels">
                    <div class="source-label" id="rockbot-label">
                        🎵 RockBot Audio
                    </div>
                    <div class="source-label" id="wireless-label">
                        🎤 Wireless Mic
                    </div>
                </div>

                <div class="toggle-switch-container">
                    <div class="toggle-switch" id="audioToggle">
                        <div class="toggle-slider">🎵</div>
                    </div>
                </div>

                <div class="status-display">
                    <div class="current-source" id="currentSource">Current Source: RockBot Audio</div>
                    <div class="loading-indicator" id="loadingIndicator">
                        <div class="spinner"></div>
                        <p>Switching audio sources...</p>
                    </div>
                    <div class="progress-bar">
                        <div class="progress-fill" id="progressFill"></div>
                    </div>
                </div>

                <div class="zone-list" id="zoneList">
                    <div class="zone-item" data-zone="Bowling Bar Music">
                        <strong>Bowling Bar Music</strong>
                        <div class="zone-status">Ready</div>
                    </div>
                    <div class="zone-item" data-zone="Axe/Billiards Music">
                        <strong>Axe/Billiards Music</strong>
                        <div class="zone-status">Ready</div>
                    </div>
                    <div class="zone-item" data-zone="Bowling Music">
                        <strong>Bowling Music</strong>
                        <div class="zone-status">Ready</div>
                    </div>
                    <div class="zone-item" data-zone="Rink Music">
                        <strong>Rink Music</strong>
                        <div class="zone-status">Ready</div>
                    </div>
                    <div class="zone-item" data-zone="Facility Zone Pro">
                        <strong>Facility Zone Pro</strong>
                        <div class="zone-status">Ready</div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Audio zone configuration
        const audioZones = {
            'Bowling Bar Music': '192.168.8.28',
            'Axe/Billiards Music': '192.168.8.27',
            'Bowling Music': '192.168.8.25',
            'Rink Music': '192.168.8.15',
            'Facility Zone Pro': '192.168.8.81'
        };

        // Audio source channels
        const audioSources = {
            rockbot: 10,    // RockBot Audio
            wireless: 8     // Wireless Mic TX
        };

        let currentSource = 'rockbot'; // Default to RockBot
        let isUpdating = false;

        // Initialize the page
        document.addEventListener('DOMContentLoaded', function() {
            updateUI();
            
            // Add click handler to toggle switch
            document.getElementById('audioToggle').addEventListener('click', function() {
                if (!isUpdating) {
                    toggleAudioSource();
                }
            });
        });

        function updateUI() {
            const toggle = document.getElementById('audioToggle');
            const slider = toggle.querySelector('.toggle-slider');
            const currentSourceEl = document.getElementById('currentSource');
            const rockbotLabel = document.getElementById('rockbot-label');
            const wirelessLabel = document.getElementById('wireless-label');

            if (currentSource === 'wireless') {
                toggle.classList.add('wireless');
                slider.innerHTML = '🎤';
                currentSourceEl.textContent = 'Current Source: Wireless Mic';
                rockbotLabel.className = 'source-label inactive';
                wirelessLabel.className = 'source-label active';
            } else {
                toggle.classList.remove('wireless');
                slider.innerHTML = '🎵';
                currentSourceEl.textContent = 'Current Source: RockBot Audio';
                rockbotLabel.className = 'source-label active';
                wirelessLabel.className = 'source-label inactive';
            }
        }

        async function toggleAudioSource() {
            if (isUpdating) return;
            
            isUpdating = true;
            const newSource = currentSource === 'rockbot' ? 'wireless' : 'rockbot';
            
            // Show loading state
            showLoading(true);
            resetZoneStates();
            updateProgress(10);
            
            try {
                // Update all zones to show they're updating
                const zoneNames = Object.keys(audioZones);
                zoneNames.forEach(zoneName => {
                    updateZoneStatus(zoneName, 'updating', 'Switching...');
                });
                
                updateProgress(25);
                
                // Make the actual switch request to backend
                const response = await switchAllZones(newSource);
                
                updateProgress(75);
                
                // Process the results
                if (response.results) {
                    Object.keys(response.results).forEach(zoneName => {
                        const result = response.results[zoneName];
                        if (result.success) {
                            updateZoneStatus(zoneName, 'success', 'Switched ✓');
                        } else {
                            updateZoneStatus(zoneName, 'error', 'Failed ✗');
                        }
                    });
                }
                
                updateProgress(100);
                
                // Update current source and UI if any zones succeeded
                if (response.success) {
                    currentSource = newSource;
                    updateUI();
                }
                
                // Show completion message
                console.log('Audio toggle response:', response.message);
                
                setTimeout(() => {
                    showLoading(false);
                    resetZoneStates();
                }, 2000);
                
            } catch (error) {
                console.error('Error switching audio source:', error);
                showLoading(false);
                
                // Update all zones to show error
                const zoneNames = Object.keys(audioZones);
                zoneNames.forEach(zoneName => {
                    updateZoneStatus(zoneName, 'error', 'Error ✗');
                });
                
                setTimeout(() => {
                    resetZoneStates();
                }, 3000);
            } finally {
                isUpdating = false;
            }
        }

        function switchAllZones(source) {
            return new Promise((resolve, reject) => {
                console.log('Sending request to audio_toggle_handler.php with source:', source);
                
                $.ajax({
                    url: 'audio_toggle_handler.php',
                    type: 'POST',
                    data: {
                        source: source
                    },
                    dataType: 'json',
                    timeout: 30000, // Longer timeout for multiple zone switches
                    success: function(response) {
                        console.log('Response received:', response);
                        resolve(response);
                    },
                    error: function(xhr, status, error) {
                        console.error('AJAX Error Details:', {
                            status: status,
                            error: error,
                            responseText: xhr.responseText,
                            statusCode: xhr.status
                        });
                        reject(new Error(`AJAX Error: ${status} - ${error}`));
                    }
                });
            });
        }

        function updateZoneStatus(zoneName, status, message) {
            const zoneElement = document.querySelector(`[data-zone="${zoneName}"]`);
            if (zoneElement) {
                zoneElement.className = `zone-item ${status}`;
                const statusElement = zoneElement.querySelector('.zone-status');
                if (statusElement) {
                    statusElement.textContent = message;
                }
            }
        }

        function resetZoneStates() {
            const zones = document.querySelectorAll('.zone-item');
            zones.forEach(zone => {
                zone.className = 'zone-item';
                const statusElement = zone.querySelector('.zone-status');
                if (statusElement) {
                    statusElement.textContent = 'Ready';
                }
            });
        }

        function showLoading(show) {
            const loadingIndicator = document.getElementById('loadingIndicator');
            loadingIndicator.style.display = show ? 'block' : 'none';
            
            if (!show) {
                updateProgress(0);
            }
        }

        function updateProgress(percentage) {
            const progressFill = document.getElementById('progressFill');
            progressFill.style.width = percentage + '%';
        }
    </script>
</body>
</html>
