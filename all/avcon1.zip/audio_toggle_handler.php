<?php
/**
 * Audio Toggle Backend Handler
 * Dedicated endpoint for switching audio zones between RockBot and Wireless Mic
 */

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Set response content type to JSON
header('Content-Type: application/json');

// Only process POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Only POST requests allowed']);
    exit;
}

// Define audio zones with their IP addresses
$audioZones = [
    'Bowling Bar Music' => '192.168.8.28',
    'Axe/Billiards Music' => '192.168.8.27',
    'Bowling Music' => '192.168.8.25',
    'Rink Music' => '192.168.8.15',
    'Facility Zone Pro' => '192.168.8.81'
];

// Define audio source channels
$audioSources = [
    'rockbot' => 10,    // RockBot Audio
    'wireless' => 8     // Wireless Mic TX
];

/**
 * Simple API call function for this specific use case
 */
function makeSimpleApiCall($deviceIp, $channel) {
    $apiUrl = "http://$deviceIp/cgi-bin/api/command/channel";
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $apiUrl);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $channel);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: text/plain']);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);
    
    return [
        'success' => ($httpCode === 200 && !$error),
        'response' => $response,
        'httpCode' => $httpCode,
        'error' => $error
    ];
}

// Initialize response
$response = ['success' => false, 'message' => '', 'results' => []];

try {
    // Check if we have a valid source
    $source = $_POST['source'] ?? null;
    if (!$source || !isset($audioSources[$source])) {
        throw new Exception('Invalid audio source specified');
    }
    
    $targetChannel = $audioSources[$source];
    $successCount = 0;
    $failureCount = 0;
    
    // Process each audio zone
    foreach ($audioZones as $zoneName => $zoneIp) {
        try {
            // Make the API call to change channel
            $result = makeSimpleApiCall($zoneIp, $targetChannel);
            
            if ($result['success']) {
                $successCount++;
                $response['results'][$zoneName] = [
                    'success' => true,
                    'message' => 'Successfully switched to channel ' . $targetChannel,
                    'details' => $result['response']
                ];
            } else {
                $failureCount++;
                $response['results'][$zoneName] = [
                    'success' => false,
                    'message' => 'Failed to switch channel',
                    'error' => $result['error'] ?: 'HTTP ' . $result['httpCode'],
                    'details' => $result['response']
                ];
            }
        } catch (Exception $e) {
            $failureCount++;
            $response['results'][$zoneName] = [
                'success' => false,
                'message' => 'Error: ' . $e->getMessage()
            ];
        }
        
        // Add a small delay between zone switches for stability
        usleep(200000); // 200ms delay
    }
    
    // Determine overall success
    if ($failureCount === 0) {
        $response['success'] = true;
        $response['message'] = "All $successCount zones successfully switched to " . 
                              ($source === 'rockbot' ? 'RockBot Audio' : 'Wireless Mic');
    } else if ($successCount > 0) {
        $response['success'] = true; // Partial success
        $response['message'] = "$successCount zones succeeded, $failureCount zones failed";
    } else {
        $response['message'] = "All zones failed to switch";
    }
    
    // Add debug info
    $response['debug'] = [
        'source' => $source,
        'targetChannel' => $targetChannel,
        'processedZones' => count($audioZones),
        'timestamp' => date('Y-m-d H:i:s')
    ];
    
} catch (Exception $e) {
    $response['message'] = 'Error: ' . $e->getMessage();
    $response['debug'] = [
        'error' => $e->getMessage(),
        'timestamp' => date('Y-m-d H:i:s')
    ];
}

// Send response
echo json_encode($response);
exit;
?>
